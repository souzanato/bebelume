/**
 * Registra todos os blocos do Bebelume
 */

import './blocks/andar-casinha-bebelume';
import './blocks/andar-castelinho-bebelume';
import './blocks/telhado-casinha-bebelume';
import './blocks/telhado-castelinho-bebelume';
import './blocks/terreo-casinha-bebelume';
import './blocks/terreo-castelinho-bebelume';